
clear all
close all

% General Paths
sep = filesep;
audio_root_path = ['..' sep 'audio'];
precalc_data_root_path = 'files';

%% PROCESSING

audio_files = files_in_path(audio_root_path, 'wav');
nfiles = length(audio_files);

for f = 1 : nfiles
    % Actual audio filename
    [path,audio_filename,ext] = fileparts(audio_files(f).name);
    
    % Pre-computed data path
    precalc_data_path = [precalc_data_root_path sep audio_filename];
    
    % Pre-computed data filenames
    f0_data_file = [precalc_data_path sep audio_filename '_f0_data.mat'];
    f0gram_data_file = [precalc_data_path sep audio_filename '_f0gram_data.mat'];
    % Archivo de texto con el contorno de f0
    f0_labels_file = [precalc_data_path sep audio_filename '_f0.dat'];
    
    % fcht computation
    if (~exist(f0_data_file,'file'))
         disp(['Procesando archivo ' audio_files(f).name])
        % read audio file
        [y fs] = wavread(audio_files(f).name);
        if (~exist(precalc_data_path,'dir'))
            mkdir(precalc_data_path);
        end
        disp('Estimado el F0grama usando la STFChT')
        tic
        [t f0_det f0_salience f0s f0_hyps_indxs chr_hyps_indxs f0gram chirp_rates] = f0gram_computation(y,fs);
        toc
        save(f0_data_file, 't', 'f0_det', 'f0_salience', 'f0s');
        save(f0gram_data_file, 't', 'f0s', 'f0gram', 'f0_hyps_indxs', 'chr_hyps_indxs', 'chirp_rates');
        clear f0gram f0_hyps_indxs chr_hyps_indxs chirp_rates;
        
        % Se salvan los datos en un archivo de texto
        % Formato: time f0_contour normalized_salience corrected
        f0_contour = f0s(f0_det);
        f0_salience = f0_salience/max(abs(f0_salience));
        fid = fopen(f0_labels_file, 'w');
        for i = 1:length(t)
            fprintf(fid, '%0.9f\t%0.9f\t%0.9f\t%g\n', [t(i) f0_contour(i) f0_salience(i) 0]);
        end
        fclose(fid);
        
    else
        disp(['El archivo <<' audio_files(f).name '>> ya fue procesado.'])
    end
    
end




