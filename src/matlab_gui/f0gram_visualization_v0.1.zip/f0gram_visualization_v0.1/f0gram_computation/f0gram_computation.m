function [t f0_det f0_salience f0s f0_hyps_indxs chr_hyps_indxs f0gram chirp_rates] = f0gram_computation(y,fs)

% add path to the FanChirp code directories
addpath(genpath('FanChirp_F0gram_computation'))

% set FChT parameters
set_parameters;

% only one channel (left)
if (size(y,2) > 1); y = y(:,1); disp('WARNING: only left channel considered'); end

% design for efficient fcht computation
[warps f0s accums] = design_fcht_db(fs, nfft, fmax, warp_params, f0_params, glogs_params);

% fcht computation
[t f0gram f0_hyps_indxs chr_hyps_indxs] = ...
    compute_fcht_db(y, fs, nfft, fmax, hop, warps, f0s, accums, f0_params, glogs_params);

f0_salience = max(f0gram,[],1);
f0_det = f0_hyps_indxs(1,:);
chirp_rates = warps.chirp_rates;

end
