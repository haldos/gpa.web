% script to set FChT analysis parameters
% see below for a description of each parameter

if(isunix); dir_slash = '/'; else dir_slash = '\'; end    

%% =============  WARPING PARAMETERS  =============
% maximum frequency of interest
fmax = 10000; % Hz
% number of samples of the warped signal frame
warp_params.nsamps_twarp = 2048;
% number of fft points (controls zero-padding)
nfft = warp_params.nsamps_twarp; %nfft = 3*wp.nsamps_twarp/2; 
% warping type
warp_params.warping_type = 'linear';
% maximum value of normalized frequency deviation (alpha)
warp_params.alpha_max = 6;
% number of warpings
warp_params.num_warps = 21;
% oversampling factor
warp_params.fact_over_samp = 2;
% hop in samples
hop = warp_params.fact_over_samp * 256;


%% =============   F0-GRAM PARAMETERS  =============
% minimun fundamental frequency
f0_params.f0min = 80; % Hz
% number of octaves
f0_params.num_octs = 4;
% number of f0s per octave
f = 2;
f0_params.num_f0s_per_oct = f*192;
% number of f0 hypotesis to extract
f0_params.num_f0_hyps = 10;
% whether to save the f0gram
f0_params.save_f0gram = 0;
% whether to use a f0 preference guassian function
f0_params.prefer = 1;
% mean of f0 preference guassian function (MIDI number for C4)
f0_params.prefer_mean = 60;  
% stdev of f0 preference guassian function (stdev in MIDI numbers)
f0_params.prefer_stdev = 18;  

%% ======== GATHERED LOG SPECTRUM PARAMETERS =======
% high-pass logS
glogs_params.HP_logS = 1;
% whether to attenuate subharmonics
glogs_params.att_subharms = 1;
% whether to apply the GlogS correction model 
glogs_params.apply_GlogS_model = 1; % may be changed later
% whether to learn the GlogS correction model from a labeled database
glogs_params.compute_GlogS_model = 0; % may be changed later
% model parameter variables (default values)
glogs_params.median_poly_coefs = ([-0.000000058551680 -0.000006945207775 0.002357223226588])./([f^2 f 1]);
glogs_params.sigma_poly_coefs  = ([ 0.000000092782308  0.000057283574898 0.022199903714288])./([f^2 f 1]);

