function [yticks, ylabels] = get_scale_ticks(ymin, ymax, f0s, num_f0s_per_oct, a4_freq)

yrange = ymax - ymin;

A4 = a4_freq; % reference A4 frequency for pitch grid in plots
notes_names = ['A-'; 'Bb'; 'B-'; 'C-'; 'C#'; 'D-'; 'Eb'; 'E-';  'F-'; 'F#'; 'G-'; 'Ab'];

if (yrange > num_f0s_per_oct)
    delta_cents = 100;
else
    if (yrange > num_f0s_per_oct/2)
        delta_cents = 50;
    else
        if (yrange > num_f0s_per_oct/12)
        delta_cents = 10;
        else
            delta_cents = 5;
        end
    end
end
    
kmin = ceil((100/delta_cents)*(69 + 12*log2(f0s(ymin)/A4)));
kmax = floor((100/delta_cents)*(69 + 12*log2(f0s(ymax)/A4)));

value_ticks = A4*2.^(((delta_cents/100)*(kmin:kmax)-69)/12);
yticks = interp1(f0s(ymin:ymax), ymin:ymax, value_ticks);
c = delta_cents*mod((kmin:kmax),100/delta_cents)';
k = kmin:kmax;

ylabels = cell(length(yticks),1);
for i=1:length(yticks)
    if c(i) == 0
        note = notes_names(mod(delta_cents/100*k(i)+3,12)+1,:);
        octave = floor(delta_cents/100*k(i)/12)-1;
        ylabels{i} = strcat(note,num2str(octave),'-',num2str(value_ticks(i),'%4.2f'));
    else
        ylabels{i} = strcat(num2str(c(i)),'-',num2str(value_ticks(i),'%4.2f'));
    end
end
