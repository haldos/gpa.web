function adaptive_scale_ticks(~,eventObjectHandle, f0s, num_f0s_per_oct, a4_freq)

axh = eventObjectHandle.Axes;

lim = get(axh,'ylim');
ymin = ceil(lim(1));
ymax = floor(lim(2));

[yticks, ylabels] = get_scale_ticks(ymin, ymax, f0s, num_f0s_per_oct, a4_freq);

set(axh,'YTick', yticks);
set(axh,'YTickLabel', ylabels);


