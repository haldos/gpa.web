function [f0_sint t_sint] = sintetizar_f0(t,f0_contour,envolvente,fs)

nsamp = floor(t(end)*fs)+1;
t_sint = (0:nsamp-1)/fs;

% fragmentos de melodia
mel_inds = f0_contour > 0;
deriv = mel_inds(2:end)-mel_inds(1:end-1);
starts = find(deriv>0)+1;
ends = find(deriv<0);
if (mel_inds(1)==1)
    starts = [1; starts];
end
if (mel_inds(end)==1)
    ends = [ends; length(mel_inds)];
end
nfrags = length(starts);
% Para la envolvente temporal
nwin = 251;
nm = (nwin-1)/2+1;
win = hanning(nwin);

f0_sint = zeros(nsamp,1);
for i = 1:nfrags
    if (starts(i)~=ends(i))
        samp_st = ceil(t(starts(i))*fs)+1;
        samp_end = floor(t(ends(i))*fs)+1;
        fr = interp1(t(starts(i):ends(i)),f0_contour(starts(i):ends(i)),t_sint(samp_st:samp_end),'linear','extrap');
        phi = 2*pi*cumtrapz(fr)/fs;
        f0_fr = cos(phi)';
        nn = length(f0_fr);
        if nn>nwin
            f0_fr(1:nm) = f0_fr(1:nm).*win(1:nm);
            f0_fr(end-nm+1:end) = f0_fr(end-nm+1:end).*win(end-nm+1:end);
        else
            f0_fr = f0_fr.*hanning(nn);
        end
        f0_sint(samp_st:samp_end) = f0_fr;
    end
end

env = interp1(t,envolvente,t_sint)';
f0_sint = env.*f0_sint;
