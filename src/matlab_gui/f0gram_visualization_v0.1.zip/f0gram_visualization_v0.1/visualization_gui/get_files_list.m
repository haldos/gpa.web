function list = get_files_list(path)

files = files_in_path(path, 'wav');
nfiles = length(files);


for i = 1 : nfiles
    % Actual audio filename
    [path,filename,ext] = fileparts(files(i).name);
    list(i,1) = {filename};
end
