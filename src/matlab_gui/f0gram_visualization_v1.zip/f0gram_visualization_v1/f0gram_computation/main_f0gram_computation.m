
clear all
close all

%%% Configurable part

% Nombre del archivo de audio (sin extensión)
%audio_filename = 'Bulgaria_Harvest_Song_short';
audio_filename = 'Muddy_Waters_-_Long_Distance_Call_1951_speed_correct-inicio';

%%%

% se elimina la extensión si tiene
points = strfind(audio_filename,'.');
if ~isempty(points)
    if  strcmpi(audio_filename(points(end)+1:end),'wav')
        audio_filename = audio_filename(1:points(end)-1);
    end
end

sep = filesep;
% General Paths
audio_root_path = ['..' sep 'audio'];
precalc_data_root_path = 'files';


% Path names
precalc_data_path = [precalc_data_root_path sep audio_filename];
audio_file = [audio_root_path sep audio_filename '.wav'];

% Archivos con datos precalculados
f0_data_file = [precalc_data_path sep audio_filename '_f0_data.mat'];
f0gram_data_file = [precalc_data_path sep audio_filename '_f0gram_data.mat'];
% Archivo de texto con el contorno de f0
f0_labels_file = [precalc_data_path sep audio_filename '_f0.dat'];

% Crea el directorio para los archivos de salida si no existe
if (~exist(precalc_data_path,'dir'))
    mkdir(precalc_data_path);
end

%% STFChT

% read audio file
[y fs] = wavread(audio_file);

% fcht computation
if (~exist(f0_data_file,'file'))
    disp('Estimado la frecuencia fundamental usando la STFChT')
    tic
    [t f0_det f0_salience f0s f0_hyps_indxs chr_hyps_indxs f0gram chirp_rates] = f0gram_computation(y,fs);
    toc
    save(f0_data_file, 't', 'f0_det', 'f0_salience', 'f0s');
    save(f0gram_data_file, 't', 'f0s', 'f0gram', 'f0_hyps_indxs', 'chr_hyps_indxs', 'chirp_rates');
    clear f0gram f0_hyps_indxs chr_hyps_indxs chirp_rates;
else
    disp(['Cargando los datos precalculados en el archivo <<' f0_data_file '>>'])
    load(f0_data_file);
end

%% labels file creation

f0_contour = f0s(f0_det);
f0_salience = f0_salience/max(abs(f0_salience));
    
% Se salvan los datos en un archivo de texto
% Formato: time f0_contour normalized_salience corrected
fid = fopen(f0_labels_file, 'w');
for i = 1:length(t)
    fprintf(fid, '%0.9f\t%0.9f\t%0.9f\t%g\n', [t(i) f0_contour(i) f0_salience(i) 0]);
end
fclose(fid);


%% PLOTS

frm_idx = 1:length(t);
figure
plot(frm_idx,f0_contour,'k')
axis([frm_idx(1) frm_idx(end) 0 max(f0_contour)])
title('Prominent F0')
xlabel('Frame')
ylabel('Frequency (Hz)')


