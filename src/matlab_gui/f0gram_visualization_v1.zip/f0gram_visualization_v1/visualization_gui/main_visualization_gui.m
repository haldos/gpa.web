function varargout = main_visualization_gui(varargin)
% MAIN_VISUALIZATION_GUI M-file for main_visualization_gui.fig
%      MAIN_VISUALIZATION_GUI, by itself, creates a new MAIN_VISUALIZATION_GUI or raises the existing
%      singleton*.
%
%      H = MAIN_VISUALIZATION_GUI returns the handle to a new MAIN_VISUALIZATION_GUI or the handle to
%      the existing singleton*.
%
%      MAIN_VISUALIZATION_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MAIN_VISUALIZATION_GUI.M with the given input arguments.
%
%      MAIN_VISUALIZATION_GUI('Property','Value',...) creates a new MAIN_VISUALIZATION_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before main_visualization_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to main_visualization_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help main_visualization_gui

% Last Modified by GUIDE v2.5 17-Apr-2012 00:20:07

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @main_visualization_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @main_visualization_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before main_visualization_gui is made visible.
function main_visualization_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to main_visualization_gui (see VARARGIN)

% Choose default command line output for main_visualization_gui
handles.output = hObject;

axes(handles.f0gram_axes);
axis off;
axes(handles.waveform_axes);
axis off;
linkaxes([handles.f0gram_axes handles.waveform_axes],'x')

% General paths
handles.audio_root_path = ['..' filesep 'audio'];
handles.data_root_path = ['..' filesep 'f0gram_computation' filesep 'files'];

%%%%%%%%%%%%%%%%% Handles para el control del resize %%%%%%%%%%%%%%%%%%%%%

% Largo y alto absoluto del panel de control.
% Se necesita guradar para que no cambie de tamaño en el resize.
window_ini_pos = get(handles.main_window,'Position');
cpanel_relative_pos = get(handles.control_panel,'Position');
handles.cpanel_absolute_size = [cpanel_relative_pos(3)*window_ini_pos(3)...
    cpanel_relative_pos(4)*window_ini_pos(4)];

ppanel_pos = get(handles.plots_panel,'Position');
spanel_pos = get(handles.status_panel,'Position');
sinfo_pos = get(handles.status_info_text,'Position');

handles.x_start_right_panels = ppanel_pos(1)*window_ini_pos(3);
handles.y_start_ppanel = ppanel_pos(2)*window_ini_pos(4);
handles.h_ppanel = ppanel_pos(4);
handles.height_spanel = spanel_pos(4)*window_ini_pos(4);

handles.x_end_sinfo = (1-(sinfo_pos(1)+sinfo_pos(3)))*window_ini_pos(3);
handles.y_sinfo = sinfo_pos(2)*window_ini_pos(4);
handles.w_sinfo = sinfo_pos(3)*window_ini_pos(3);
handles.h_sinfo = sinfo_pos(4)*window_ini_pos(4);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% parametros generales
handles.win_time = 10;
handles.hop_time = 9;

% se setea el valor por defecto de los popupmenu
set(handles.candidates_number_popupmenu,'Value',1); % 0:10
set(handles.balance_popupmenu,'Value',11); % -100:10:100

% se setea el valor por defecto del la frecuencia de referencia
handles.a4_freq = 440;
set(handles.edit_a4_freq,'String',num2str(handles.a4_freq));drawnow;

% mensaje al ejecutar la aplicación
set(handles.status_info_text,'String','Select a file and load the data from the File menu');drawnow;

% creación de ventana de confirmación al cerrar
set(handles.main_window,'CloseRequestFcn',@closeGUI)

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes main_visualization_gui wait for user response (see UIRESUME)
% uiwait(handles.main_window);

% --- Outputs from this function are returned to the command line.
function varargout = main_visualization_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on selection change in filelist.
function filelist_Callback(hObject, eventdata, handles)
% hObject    handle to filelist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns filelist contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox

% --- Executes during object creation, after setting all properties.
function filelist_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filelist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
audio_root_path = ['..' filesep 'audio'];
list = get_files_list(audio_root_path);
set(hObject, 'String', list);
set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));

% --- Executes on button press in next_button.
function next_button_Callback(hObject, eventdata, handles)
% hObject    handle to next_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if (handles.actual_win<handles.nwins)
    cla(handles.f0gram_axes,'reset');
    cla(handles.waveform_axes,'reset');
    handles.actual_win = handles.actual_win + 1;
    % si está el checkbox del espectrograma en true, se calcula de nuevo
    if (get(handles.spectrogram_checkbox,'Value'))
        handles.actual_win_spectrogram = compute_spectrogram(handles);
        handles.computed_actual_win_spectrogram = 1;
    else
        handles.computed_actual_win_spectrogram = 0;
    end
    % si está el checkbox de los armonicos se calcula de nuevo
    if (get(handles.harmonics_checkbox,'Value'))
        handles.actual_win_harmonics = compute_harmonics(handles);
    end
    plot_figures(handles);
    guidata(hObject, handles);
end

% --- Executes on button press in previous_button.
function previous_button_Callback(hObject, eventdata, handles)
% hObject    handle to previous_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if (handles.actual_win>1)
    cla(handles.f0gram_axes,'reset');
    cla(handles.waveform_axes,'reset');
    handles.actual_win = handles.actual_win - 1;
    % si está el checkbox del espectrograma en true, se calcula de nuevo
    if (get(handles.spectrogram_checkbox,'Value'))
        handles.actual_win_spectrogram = compute_spectrogram(handles);
        handles.computed_actual_win_spectrogram = 1;
    else
        handles.computed_actual_win_spectrogram = 0;
    end
    % si está el checkbox de los armonicos se calcula de nuevo
    if (get(handles.harmonics_checkbox,'Value'))
        handles.actual_win_harmonics = compute_harmonics(handles);
    end
    plot_figures(handles);
    guidata(hObject, handles);
end

% --- Executes on button press in edit_button.
function edit_point_Callback(hObject, eventdata, handles)
% hObject    handle to edit_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% mensaje
set(handles.status_info_text,'String','Editing points: press ''T'' to end');drawnow;

start_frame = handles.frame_idx(handles.actual_win)-1;
line = findobj(handles.f0gram_axes,'type','line','color','k');
X = get(line,'xdata');
Y = get(line,'ydata');
fin = 0;
while (~fin)
    [x,y,b]=ginput(1);
    [v,j] = min(abs(X-x));
    if ishandle(line)
        switch b
            case 1
                Y(j) = y;
            case 3
                Y(j) = NaN;
            case 116 % tecla T
                fin = 1;
            case 117 % tecla U
                [foo,Y(j)] = min(abs(2*handles.f0s(round(handles.f0_contour(start_frame+j)))-handles.f0s));
            case 100 % tecla D
                [foo,Y(j)] = min(abs(handles.f0s(round(handles.f0_contour(start_frame+j)))/2-handles.f0s));
        end
        if (~fin)
            handles=undo_push(handles,start_frame+j);
            set(line,'xdata',X,'ydata',Y)
            handles.f0_contour(start_frame+j) = Y(j);
            handles.manual(start_frame+j) = 1;
        end
        guidata(hObject, handles);
    else
        fin = 1;
    end
end

% mensaje
set(handles.status_info_text,'String','');drawnow;

guidata(hObject, handles);

% --- Executes on button press in edit_fragment.
function delete_button_Callback(hObject, eventdata, handles)
% hObject    handle to edit_fragment (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Rango de tiempo en el eje del f0grama
h_axe = handles.f0gram_axes;
time_lim = get(h_axe,'xlim');
frames = find(handles.t>time_lim(1) & handles.t<time_lim(2));
f0_lim = get(h_axe,'ylim');
frames = frames((handles.f0_contour(frames)>=f0_lim(1))&(handles.f0_contour(frames)<=f0_lim(2)));
% se guardan los datos viejos para el undo
handles = undo_push(handles,frames);
% Se cambian los valores del vector de f0
handles.f0_contour(frames) = NaN;
handles.manual(frames) = 1;
% Se cambian los valores en la figura
start_frame = handles.frame_idx(handles.actual_win);
line = findobj(handles.f0gram_axes,'type','line','color','k');
set(line,'xdata',handles.t(start_frame:start_frame+handles.win_frames-1),'ydata',handles.f0_contour(start_frame:start_frame+handles.win_frames-1))
guidata(hObject, handles);


% --- Executes on button press in down_button.
function down_button_Callback(hObject, eventdata, handles)
% hObject    handle to down_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Rango de tiempo en el eje del f0grama
h_axe = handles.f0gram_axes;
time_lim = get(h_axe,'xlim');
frames = find(handles.t>time_lim(1) & handles.t<time_lim(2));
f0_lim = get(h_axe,'ylim');
frames = frames((handles.f0_contour(frames)>=f0_lim(1))&(handles.f0_contour(frames)<=f0_lim(2)));
% se guardan los datos viejos para la el undo
handles = undo_push(handles,frames);
% Se cambian los valores del vector de f0
f0_contour = handles.f0_contour(frames)-(handles.f0s_per_oct+1);
f0_contour(f0_contour<1) = NaN;
handles.f0_contour(frames) = f0_contour;
% Se cambian los valores en la figura
start_frame = handles.frame_idx(handles.actual_win);
line = findobj(handles.f0gram_axes,'type','line','color','k');
set(line,'xdata',handles.t(start_frame:start_frame+handles.win_frames-1),'ydata',handles.f0_contour(start_frame:start_frame+handles.win_frames-1))
guidata(hObject, handles);

% --- Executes on button press in up_button.
function up_button_Callback(hObject, eventdata, handles)
% hObject    handle to up_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Rango de tiempo en el eje del f0grama
h_axe = handles.f0gram_axes;
time_lim = get(h_axe,'xlim');
frames = find(handles.t>time_lim(1) & handles.t<time_lim(2));
f0_lim = get(h_axe,'ylim');
frames = frames((handles.f0_contour(frames)>=f0_lim(1))&(handles.f0_contour(frames)<=f0_lim(2)));
% se guardan los datos viejos para la el undo
handles = undo_push(handles,frames);
% Se cambian los valores del vector de f0
f0_contour = handles.f0_contour(frames)+(handles.f0s_per_oct+1);
f0_contour(f0_contour>length(handles.f0s)) = NaN;
handles.f0_contour(frames) = f0_contour;
% Se cambian los valores en la figura
start_frame = handles.frame_idx(handles.actual_win);
line = findobj(handles.f0gram_axes,'type','line','color','k');
set(line,'xdata',handles.t(start_frame:start_frame+handles.win_frames-1),'ydata',handles.f0_contour(start_frame:start_frame+handles.win_frames-1))
guidata(hObject, handles);


% --- Executes on button press in load_data_button.
function file_menu_load_data_Callback(hObject, eventdata, handles)
% hObject    handle to load_data_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% mensaje
set(handles.status_info_text,'String','Loading data')
drawnow;

%%% Nombre de directorios usados
% Nombre del directorio de la cancion
files_list = get(handles.filelist,'String');
file_number = get(handles.filelist,'Value');
audio_filename = files_list{file_number};
% Directorios de entrada y salida
handles.data_path = [handles.data_root_path filesep audio_filename];
out_root_path = 'files';
handles.files_out_dir = [out_root_path filesep audio_filename];

%%% Archivos usados
% f0gram
f0gram_file = [handles.data_path filesep audio_filename '_f0gram_data.mat'];
% Archivo con las etiquetas y el numero de version
% crea el directorio para los archivos de salida si no existe y se define
% el nombre del archivo con las etiquetas
if (~exist(handles.files_out_dir,'dir'))
    mkdir(handles.files_out_dir);
    f0_labels_file = [handles.data_path filesep audio_filename '_f0.dat'];
    last_version = 0;
else
    [lab_filename last_version] = get_current_labels_filename(handles.files_out_dir,1);
    if (last_version==0)
        f0_labels_file = [handles.data_path filesep audio_filename '_f0.dat'];
    else
        f0_labels_file = [handles.files_out_dir filesep lab_filename];
    end
end
%%%%

% Archivo de audio
wav_file = [handles.audio_root_path filesep audio_filename '.wav'];

% load f0gram
load(f0gram_file);
[nfrecs, nframes] = size(f0gram);
% load wav
[y,fs] = wavread(wav_file);
stereo = false;
if (size(y,2) > 1); y = y(:,1); stereo = true; end

% decimación para eficiencia
dec_factor = 4;
y = decimate(y,dec_factor);
fs = fs/dec_factor;
nsamps = length(y);
t_au = (0:nsamps-1)'/fs;
% número de frames del f0gram y número de muestras de la señal en una
% ventana
hop_frames = t(2)-t(1);
win_frames = round(handles.win_time/hop_frames);
win_samp = round(handles.win_time*fs);
% Se agraga una ventana completa al final para completar la ultima ventana
frames_add = win_frames;
samp_add = win_samp;
% numero de frame y numero de muestra de comienzo de cada ventana
t_starts = 0:handles.hop_time:t(end);
nwins = length(t_starts);
frame_idx = zeros(size(t_starts));
for i = 1 : nwins
    frame_idx(i) = find(t>t_starts(i),1,'first');
end
samp_idx = round(t_starts*fs)+1;
% set candidates
nc = size(f0_hyps_indxs,1);
% contorno de f0 sin prostrocesar
f0_contour_no_proc = f0_hyps_indxs(1,:)';
% otros candidatos
f0_secondary_candidates = f0_hyps_indxs(2:nc,:)';
%%% load labels
T = dlmread(f0_labels_file, '\t');
% f0 labels
f0_contour = T(:,2);
f0_contour = interp1(f0s,1:length(f0s),f0_contour); % Los valores f0=0 quedan NaN
% salience lables
salience = T(:,3);
% manual correction label
manual = T(:,4);
% factor de normalizacion de la energia para plots
fnorm_salience = length(f0s)/max(salience);
% factor de normalizacion de la energia para amplitud unidad
fnrom_salience_unity = max(max(f0gram));
% store data
handles.t = [t t(end)+(1:frames_add)*(hop_frames)];
handles.f0s = f0s;
handles.f0gram = [f0gram zeros(nfrecs,frames_add)];
handles.y = [y; zeros(samp_add+2000,1)];
handles.t_au = [t_au; (nsamps:nsamps+samp_add-1)'/fs];
handles.fs = fs;
handles.win_frames = win_frames;
handles.win_samp = win_samp;
handles.frame_idx = frame_idx;
handles.samp_idx = samp_idx;
handles.nwins = nwins;
handles.actual_win = 1;
handles.f0_contour = [f0_contour; NaN*ones(frames_add,1)];
handles.salience = [salience*fnorm_salience; zeros(frames_add,1)];
handles.manual = [manual; zeros(frames_add,1)];
handles.frames_add = frames_add;
handles.f0_contour_no_proc = [f0_contour_no_proc; zeros(frames_add,1)];
handles.f0_secondary_candidates = [f0_secondary_candidates; zeros(frames_add,nc-1)];
handles.fnorm_salience = fnorm_salience;
handles.fnrom_salience_unity = fnrom_salience_unity;
% para el espectrograma
handles.computed_actual_win_spectrogram = 0;
handles.actual_win_spectrogram = 0;
% para armonicos
handles.actual_win_harmonics = 0;
% para construir el nombre de los archivos de salida
handles.audio_filename = audio_filename;
handles.last_version = last_version;
handles.wav_file = wav_file;
% para deshacer
handles.undo_idx = 0;
handles.undo_max_idx = 10;
handles.undo(handles.undo_max_idx).idx = [];
handles.undo(handles.undo_max_idx).f0_contour = [];
handles.undo(handles.undo_max_idx).manual = [];
handles.undo(handles.undo_max_idx).salience = [];
% fcht parameters
handles.f0_min = f0s(1);
[mi,ind_mi] = min(abs(f0s-2*handles.f0_min));
handles.f0s_per_oct = ind_mi-1;
% candidato editable
handles.editable_candidate = 1;
% nombre del archivo .mat con el f0grama - se usa para elegir 
% el candidato editable
handles.f0gram_file = f0gram_file;

% mensaje
if stereo
    set(handles.status_info_text,'String','WARNING: only left channel considered');
else
    set(handles.status_info_text,'String','')
end
drawnow;

%%% ticks y valores de los ticks del eje de f0 en la grafica
handles = set_f0_scale(handles);

% plot
plot_figures(handles);
% actualizacion de handles
guidata(hObject, handles);


% --- Executes on button press in audio_button.
function audio_button_Callback(hObject, eventdata, handles)
% hObject    handle to audio_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
h_axe = handles.waveform_axes;
% Se borra la grafica de la forma de onda de la sintesis si existe
L = findobj(h_axe,'type','line','color','r');
if (~isempty(L))
    set(L,'xdata',[],'ydata',[])
end
time_lim = get(h_axe,'xlim');
samps = handles.t_au>time_lim(1) & handles.t_au<time_lim(2);
y = handles.y(samps);

h_player = audioplayer(y, handles.fs);

f_ui_crosshairs_x_mod(h_axe, h_player, time_lim(1));
play(h_player);
pause;
stop(h_player);

function plot_figures(handles)

% Obtencion de los valores del checkbox para graficar el contorno sin
% procesar y el numero de candidatos
plot_no_proc = get(handles.f0_no_proc_checkbox,'Value');
candidates_list = get(handles.candidates_number_popupmenu,'String');
candidates_idx = get(handles.candidates_number_popupmenu,'Value');
ncandidates = str2double(candidates_list{candidates_idx});
% Graficar  salience?
plot_salience = get(handles.salience_checkbox,'Value');
% Mostrar correccion manual?
plot_manual = get(handles.manual_checkbox,'Value');
% Mostrar espectrograma en lugar de f0grama
plot_spec = get(handles.spectrogram_checkbox,'Value');
% Mostrar armónicos
plot_harmonics = get(handles.harmonics_checkbox,'Value');

actual_win = handles.actual_win;
samp_idx = handles.samp_idx(actual_win):handles.samp_idx(actual_win)+handles.win_samp-1;
y = handles.y(samp_idx);
t_au = handles.t_au(samp_idx);
frame_idx = handles.frame_idx(actual_win):handles.frame_idx(actual_win)+handles.win_frames-1;
f0gram = handles.f0gram(:,frame_idx);
t = handles.t(frame_idx);
f0_contour = handles.f0_contour(frame_idx);
f_axis_idx = 1:length(handles.f0s);

if (plot_spec)
    spec = handles.actual_win_spectrogram;
end
if (plot_harmonics)
    harmonics = handles.actual_win_harmonics;
end
if (plot_manual)
    manual = handles.manual(frame_idx);
end
if (plot_salience)
    salience = handles.salience(frame_idx);
end
if (plot_no_proc)
    f0_contour_no_proc = handles.f0_contour_no_proc(frame_idx);
end
if (ncandidates>1)
    f0_secondary_candidates = handles.f0_secondary_candidates(frame_idx,1:ncandidates-1);
end


% colores de los candidatos
cmin = 0.4;
cmax = 1;
colors = linspace(cmin,cmax,ncandidates-1);

axes(handles.f0gram_axes);
if (plot_spec)
    imagesc(t,f_axis_idx,spec);axis xy;axis tight
else
    imagesc(t,f_axis_idx,f0gram);axis xy;axis tight
end
hold on
if (plot_harmonics)
    plot(t,harmonics,'.','Color',[0.4 0.4 0.4])
end
if (plot_salience)
    plot(t,salience,'r.-')
end
if (ncandidates>1)
    for i = 1 : ncandidates-1
        plot(t,f0_secondary_candidates(:,i),'.','Color',colors(i)*ones(1,3))
    end
end
if (plot_no_proc)
    plot(t,f0_contour_no_proc,'.','Color',[0.7 0.7 0.7]) 
end
if (ncandidates>0)
    plot(t,f0_contour,'k.')
end
if (plot_manual)
    plot(t(manual==1),f0_contour(manual==1),'r.')
end
set(gca,'YTick', handles.yticks)
set(gca,'YTickLabel', handles.ylabels)
set(gca,'FontSize',7);
grid

axes(handles.waveform_axes)
plot(t_au,y,'k');axis tight
ylim([-1 1])
set(gca,'FontSize',7);


% --- Executes on button press in f0_button.
function f0_button_Callback(hObject, eventdata, handles)
% hObject    handle to f0_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

h_axe = handles.waveform_axes;
time_lim = get(h_axe,'xlim');
samp_ini = find(handles.t_au>time_lim(1),1,'first');
frames = find(handles.t>time_lim(1) & handles.t<time_lim(2));
f0_contour = handles.f0_contour(frames);
salience = handles.salience(frames)/max(handles.salience);
inds_nan = isnan(f0_contour);
f0_contour(inds_nan) = 0;
inds_no_cero = find(f0_contour>0);
f0_contour(inds_no_cero) = handles.f0s(round(f0_contour(inds_no_cero)));
t = handles.t(frames)-time_lim(1);
[f0_sint t_sint] = sintetizar_f0(t,f0_contour,salience,handles.fs);

% Se borra la grafica de la forma de onda de la sintesis si existe
L = findobj(h_axe,'type','line','color','r');
if (~isempty(L))
    set(L,'xdata',[],'ydata',[])
end
% Se grafica la forma de onda de la sintesis
axes(handles.waveform_axes)
hold on
plot(handles.t_au(samp_ini)+t_sint,f0_sint,'r')
hold off

h_player = audioplayer(f0_sint, handles.fs);
f_ui_crosshairs_x_mod(h_axe, h_player, time_lim(1));
play(h_player);
pause;
stop(h_player);

% --- Executes on button press in together_button.
function together_button_Callback(hObject, eventdata, handles)
% hObject    handle to together_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
h_axe = handles.waveform_axes;
time_lim = get(h_axe,'xlim');
samp_ini = find(handles.t_au>time_lim(1),1,'first');
frames = find(handles.t>time_lim(1) & handles.t<time_lim(2));
f0_contour = handles.f0_contour(frames);
salience = handles.salience(frames)/max(handles.salience);
inds_nan = isnan(f0_contour);
f0_contour(inds_nan) = 0;
inds_no_cero = find(f0_contour>0);
f0_contour(inds_no_cero) = handles.f0s(round(f0_contour(inds_no_cero)));
t = handles.t(frames)-time_lim(1);
[f0_sint t_sint] = sintetizar_f0(t,f0_contour,salience,handles.fs);

% Se borra la grafica de la forma de onda de la sintesis si existe
L = findobj(h_axe,'type','line','color','r');
if (~isempty(L))
    set(L,'xdata',[],'ydata',[])
end
% Se grafica la forma de onda de la sintesis
axes(handles.waveform_axes)
hold on
plot(handles.t_au(samp_ini)+t_sint,f0_sint,'r')
hold off

samps = samp_ini:samp_ini+length(f0_sint)-1;
% Mezcla en función del valor del balance
% obtencion del valor de balance
balance_list = get(handles.balance_popupmenu,'String');
balance_idx = get(handles.balance_popupmenu,'Value');
balance = str2double(balance_list{balance_idx});
% mezcla
y = ((100-balance)*(handles.y(samps))+(100+balance)*f0_sint)/200;

% reproduce el audio
h_player = audioplayer(y, handles.fs);
f_ui_crosshairs_x_mod(h_axe, h_player, time_lim(1));
play(h_player);
pause;
stop(h_player);

% --- Executes on button press in f0_no_proc_checkbox.
function f0_no_proc_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to f0_no_proc_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: get(hObject,'Value') returns toggle state of f0_no_proc_checkbox
add_new_plot_in_axes(handles)

% --- Executes on selection change in candidates_number_popupmenu.
function candidates_number_popupmenu_Callback(hObject, eventdata, handles)
% hObject    handle to candidates_number_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
add_new_plot_in_axes(handles)

% --- Executes during object creation, after setting all properties.
function candidates_number_popupmenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to candidates_number_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
set(hObject, 'String', num2cell((0:10)'));
set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));

% --- Executes on selection change in balance_popupmenu.
function balance_popupmenu_Callback(hObject, eventdata, handles)
% hObject    handle to balance_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: contents = get(hObject,'String') returns balance_popupmenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from
%        balance_popupmenu

% --- Executes during object creation, after setting all properties.
function balance_popupmenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to balance_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
set(hObject, 'String', num2cell((-100:10:100)'));
set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));

% --- Executes on button press in salience_checkbox.
function salience_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to salience_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of salience_checkbox
add_new_plot_in_axes(handles)

function add_new_plot_in_axes(handles)
% se obtienen los limites actuales de los ejes
f0_axe = handles.f0gram_axes;
wav_axe = handles.waveform_axes;
time_lim = get(f0_axe,'xlim');
f0_lim = get(f0_axe,'ylim');
amp_lim = get(wav_axe,'ylim');

% Se borran las graficas
axes(handles.f0gram_axes);hold off
axes(handles.waveform_axes);hold off
% Se grafican con los nuevos parámetros
plot_figures(handles)

% se restablecen los limites de los ejes - por si hay zoom
zoom(f0_axe,'reset') 
set(f0_axe,'xlim',time_lim);
set(f0_axe,'ylim',f0_lim);
set(wav_axe,'ylim',amp_lim);


% --- Executes on button press in manual_checkbox.
function manual_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to manual_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of manual_checkbox
add_new_plot_in_axes(handles)

function save_labels(handles)

% Se pasa a Hz
f0_contour = handles.f0_contour;
f0_contour(~isnan(f0_contour)) = handles.f0s(round(f0_contour(~isnan(f0_contour))));
% Se eliminan los NaN
f0_contour(isnan(f0_contour)) = 0;

% datos a almacenar
% Formato: time f0_postprocessed salience corrected
D = [handles.t' f0_contour handles.salience/handles.fnorm_salience handles.manual];

% nombre del archivo - el formato es distinto para el candidato mas
% prominente y el resto.
actual_version = handles.last_version + 1;
if (handles.editable_candidate==1)
    f0_labels_file = [handles.files_out_dir filesep handles.audio_filename '_f0_v' num2str(actual_version) '.dat'];
else
    f0_labels_file = [handles.files_out_dir filesep handles.audio_filename '_cand' num2str(handles.editable_candidate) '_f0_v' num2str(actual_version) '.dat'];
end
    
    
% se salvan los datos
% Formato: time f0_postprocessed salience corrected
fid = fopen(f0_labels_file, 'w');
for i = 1:length(handles.t)-handles.frames_add
    fprintf(fid, '%0.9f\t%0.9f\t%0.9f\t%g\n', D(i,:));
end
fclose(fid);

function save_audio(handles)

% Acondicionamiento del contorno de f0
f0_contour = handles.f0_contour;
f0_contour(~isnan(f0_contour)) = handles.f0s(round(f0_contour(~isnan(f0_contour))));
% Se eliminan los NaN
f0_contour(isnan(f0_contour)) = 0;

% Lectura del archivo de audio con el canal de voz
[y, fs] = wavread(handles.wav_file);

% Sintesis de la estimación
f0_sint = sintetizar_f0(handles.t,f0_contour,handles.salience/max(handles.salience),fs);

diff_samp = length(y) - length(f0_sint);
if (diff_samp>0)
    f0_sint = [f0_sint; zeros(diff_samp,1)];
else
    f0_sint = f0_sint(1:end+diff_samp);
end

% Nombre del archivo de salida
f0_synthesis_file = [handles.files_out_dir filesep handles.audio_filename '_f0.wav'];
wavwrite([y f0_sint],fs,f0_synthesis_file)

function spec = compute_spectrogram(handles)

set(handles.status_info_text,'String','Computing spectrogram');drawnow;

fs = handles.fs;
actual_win = handles.actual_win;
frame_idx = handles.frame_idx(actual_win):handles.frame_idx(actual_win)+handles.win_frames-1;
t = handles.t(frame_idx);

nwin = 1024;
hop = round((t(2)-t(1))*fs);

samp_ini = round(t(1)*fs)-nwin/2;
nsamps = hop*(handles.win_frames-1)+nwin;
y = handles.y(samp_ini:samp_ini+nsamps-1);

[spec,f,t_fr] = spectrogram(y,hanning(nwin),nwin-hop,4*nwin,fs);
spec = interp1(f,10*log10(abs(spec)+1),handles.f0s);

set(handles.status_info_text,'String','');drawnow;


% --- Executes on button press in spectrogram_checkbox.
function spectrogram_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to spectrogram_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of spectrogram_checkbox

if (get(hObject,'Value'))
    if (~handles.computed_actual_win_spectrogram)
        handles.actual_win_spectrogram = compute_spectrogram(handles);
        handles.computed_actual_win_spectrogram = 1;
        guidata(hObject, handles);
    end
end

add_new_plot_in_axes(handles)


function status_info_text_Callback(hObject, eventdata, handles)
% hObject    handle to status_info_text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of status_info_text as text
%        str2double(get(hObject,'String')) returns contents of status_info_text as a double

% --- Executes during object creation, after setting all properties.
function status_info_text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to status_info_text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

function closeGUI(src,evnt)

selection = questdlg('Do you want to close without save?',...
    'Close Request Function',...
    'Yes','No','Yes');

switch selection,
    case 'Yes',
        delete(gcf)
    case 'No'
        return
end

function handles = undo_push(handles,idx)

if (handles.undo_idx < handles.undo_max_idx)
    handles.undo_idx = handles.undo_idx + 1;
else
    handles.undo(1:handles.undo_max_idx-1) = handles.undo(2:handles.undo_max_idx);
end

handles.undo(handles.undo_idx).idx = idx;
handles.undo(handles.undo_idx).f0_contour = handles.f0_contour(idx);
handles.undo(handles.undo_idx).manual = handles.manual(idx);
handles.undo(handles.undo_idx).salience = handles.salience(idx);


% --- Executes on button press in undo_pushbutton.
function undo_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to undo_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if (handles.undo_idx > 0)
    undo_dat = handles.undo(handles.undo_idx);
    handles.f0_contour(undo_dat.idx) = undo_dat.f0_contour;
    handles.manual(undo_dat.idx) = undo_dat.manual;
    handles.salience(undo_dat.idx) = undo_dat.salience;
    handles.undo_idx = handles.undo_idx-1;
    add_new_plot_in_axes(handles);
    guidata(hObject, handles);
end


function harmonics = compute_harmonics(handles)

set(handles.status_info_text,'String','Computing harmonics');drawnow;

actual_win = handles.actual_win;
frames = handles.frame_idx(actual_win):handles.frame_idx(actual_win)+handles.win_frames-1;
f0_contour = handles.f0_contour(frames);
m = min(f0_contour);
if (~isnan(m)) % si son todos NaN (ventana de silencio), se deveulve NaNs
    f0_min = handles.f0s(round(m));
    f0_max = handles.f0s(end);
    nharm = floor(f0_max/f0_min)-1;
    harmonics = NaN*ones(handles.win_frames,nharm);
    
    for i = 1 : handles.win_frames
        if (~isnan(f0_contour(i)))
            f0 = handles.f0s(round(f0_contour(i)));
            nharm = floor(f0_max/f0);
            harmonics(i,1:nharm-1) = handles.f0s_per_oct*log2(((2:nharm)'*f0)/handles.f0_min)+1;
        end
    end
    
else
    harmonics = NaN*ones(handles.win_frames,1);
end
set(handles.status_info_text,'String','');drawnow;
   

% --- Executes on button press in harmonics_checkbox.
function harmonics_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to harmonics_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of harmonics_checkbox

if (get(hObject,'Value'))
    handles.actual_win_harmonics = compute_harmonics(handles);
    guidata(hObject, handles);
end

add_new_plot_in_axes(handles)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% Funciones del Menu File %%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% --------------------------------------------------------------------
function file_menu_Callback(hObject, eventdata, handles)
% hObject    handle to file_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function file_menu_save_audio_Callback(hObject, eventdata, handles)
% hObject    handle to file_menu_save_audio (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% mensaje
set(handles.status_info_text,'String','Saving audio');drawnow;
save_audio(handles);
% mensaje
set(handles.status_info_text,'String','');drawnow;

% --------------------------------------------------------------------
function file_menu_save_labels_Callback(hObject, eventdata, handles)
% hObject    handle to file_menu_save_labels (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% mensaje
set(handles.status_info_text,'String','Saving labels');drawnow;
save_labels(handles);
% mensaje
set(handles.status_info_text,'String','');drawnow;

% --------------------------------------------------------------------
function file_menu_save_all_Callback(hObject, eventdata, handles)
% hObject    handle to file_menu_save_all (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.status_info_text,'String','Saving data');drawnow;
save_labels(handles);
save_audio(handles);
delete(gcf)

% --------------------------------------------------------------------
function file_menu_exit_Callback(hObject, eventdata, handles)
% hObject    handle to file_menu_exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
delete(gcf)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% Funciones para el resize de la ventana %%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% --- Executes when control_panel is resized.
function control_panel_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to control_panel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% se mantiene constante el tamaño de panel de control.
window_actual_pos = get(handles.main_window,'Position');
cpanel_size = handles.cpanel_absolute_size./window_actual_pos(3:4);
set(hObject,'Position',[0 1-cpanel_size(2) cpanel_size]);

% --- Executes when status_panel is resized.
function status_panel_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to status_panel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
window_actual_pos = get(handles.main_window,'Position');

% ajuste del uicontrol status_info_text
x = (window_actual_pos(3) - (handles.x_end_sinfo + handles.w_sinfo))/window_actual_pos(3); 
y = handles.y_sinfo/window_actual_pos(4);
w = handles.w_sinfo/window_actual_pos(3);
h = handles.h_sinfo/window_actual_pos(4);
set(handles.status_info_text,'Position',[x y w h])

% ajuste del panel
x = handles.x_start_right_panels/window_actual_pos(3);
h = handles.height_spanel/window_actual_pos(4);
set(hObject,'Position',[x 0 1-x h]);


% --- Executes when plots_panel is resized.
function plots_panel_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to plots_panel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
window_actual_pos = get(handles.main_window,'Position');
x = handles.x_start_right_panels/window_actual_pos(3);
y = handles.y_start_ppanel/window_actual_pos(4);
set(hObject,'Position',[x y 1-x 1-y]);

function main_window_ResizeFcn(hObject, eventdata, handles)
% no se hace nada especial


function edit_a4_freq_Callback(hObject, eventdata, handles)
% hObject    handle to edit_a4_freq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_a4_freq as text
%        str2double(get(hObject,'String')) returns contents of edit_a4_freq as a double
handles.a4_freq = str2double(get(hObject,'String'));
lim = get(handles.f0gram_axes,'ylim');
ymin = ceil(lim(1));
ymax = floor(lim(2));
[yticks, ylabels] = get_scale_ticks(ymin, ymax, handles.f0s, handles.f0s_per_oct, handles.a4_freq);
set(handles.f0gram_axes,'YTick', yticks);
set(handles.f0gram_axes,'YTickLabel', ylabels);
handles = set_f0_scale(handles);
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit_a4_freq_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_a4_freq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.

% --------------------------------------------------------------------
function zoom_in_tool_OnCallback(hObject, eventdata, handles)
% hObject    handle to zoom_in_tool (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(zoom(handles.f0gram_axes),'ActionPostCallback', {@adaptive_scale_ticks, handles.f0s, handles.f0s_per_oct, handles.a4_freq});

% --------------------------------------------------------------------
function zoom_out_tool_OnCallback(hObject, eventdata, handles)
% hObject    handle to zoom_out_tool (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(zoom(handles.f0gram_axes),'ActionPostCallback', {@adaptive_scale_ticks, handles.f0s, handles.f0s_per_oct, handles.a4_freq});


function handles = set_f0_scale(handles)

[yticks, ylabels] = get_scale_ticks(1, length(handles.f0s), handles.f0s, handles.f0s_per_oct, handles.a4_freq);
handles.ylabels = ylabels;
handles.yticks = yticks;


% --------------------------------------------------------------------
function pan_tool_OnCallback(hObject, eventdata, handles)
% hObject    handle to pan_tool (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(pan,'ActionPostCallback', {@adaptive_scale_ticks, handles.f0s, handles.f0s_per_oct, handles.a4_freq});


% --------------------------------------------------------------------
function file_menu_save_figure_Callback(hObject, eventdata, handles)
% hObject    handle to file_menu_save_figure (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Se crea una nueva figura
new_fig = figure;
% Se crea una copia de la figura en la gui
new_axes = copyobj(handles.f0gram_axes,new_fig);
set(new_axes,'Position',[0.1500    0.1100    0.8    0.8150]);
ylabel('Frequency (Hz)','FontSize',10)
xlabel('Time (s)','FontSize',10)
% se remplazan los guiones bajos por espacios del nombre del archivo para
% guardar el titulo
ind = strfind(handles.audio_filename,'_');
fig_title = handles.audio_filename;
fig_title(ind) = ' ';
title(fig_title,'FontSize',10);
% dialogo para guardar archivo
[filename_eps, path] = uiputfile('*.eps','Save Figure As .eps',handles.audio_filename);
% se imprime la figura

if (filename_eps~=0) % si no se cancelo la operación de guardar
    
    print(new_fig,'-depsc2',[path filename_eps]);
    
    % ruta del archivo .mat con los datos
    % se elimina la extension
    [~,filename,ext] = fileparts(filename_eps);
    if (length(path)==0)
        path = '.';
    end
    filename_mat = [path filename '.mat'];
    
    % se guardan datos para reconstruir la figura
    f0gram_f0_min = handles.f0s(1);
    f0gram_f0s_per_oct = handles.f0s_per_oct;
    audio_filename = handles.audio_filename;
    
    fig_a4_freq = handles.a4_freq;
    
    f0idx_lim = get(handles.f0gram_axes,'ylim');
    frameidx_lim = get(handles.f0gram_axes,'xlim');
    
    [~, fig_frame_idx_min] = min(abs(frameidx_lim(1)-handles.t));
    [~, fig_frame_idx_max] = min(abs(frameidx_lim(2)-handles.t));
    
    fig_f0_idx_min = ceil(max(f0idx_lim(1),1));
    fig_f0_idx_max = floor(min(f0idx_lim(2),length(handles.f0s)));
    %fig_frame_idx_min = handles.frame_idx(handles.actual_win)+ceil(frameidx_lim(1));
    %fig_frame_idx_max = handles.frame_idx(handles.actual_win)+floor(frameidx_lim(2));
    
    fig_f0_min = handles.f0s(fig_f0_idx_min);
    fig_f0_max = handles.f0s(fig_f0_idx_max);
    fig_t_min = handles.t(fig_frame_idx_min);
    fig_t_max = handles.t(fig_frame_idx_max);
    
    save(filename_mat, 'audio_filename', 'f0gram_f0_min', 'f0gram_f0s_per_oct', 'fig_a4_freq', ...
        'fig_f0_idx_min', 'fig_f0_idx_max', 'fig_frame_idx_min', 'fig_frame_idx_max', ...
        'fig_f0_min', 'fig_f0_max', 'fig_t_min', 'fig_t_max');
    
end

close;


% --------------------------------------------------------------------
function preferences_menu_Callback(hObject, eventdata, handles)
% hObject    handle to preferences_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function pref_menu_plot_time_axis_Callback(hObject, eventdata, handles)
% hObject    handle to pref_menu_plot_time_axis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

prompt = {'Window Time','Window Hop'};
dlg_title = 'Plots Parameters';
num_lines = 1;
def = {num2str(handles.win_time), num2str(handles.hop_time)};
answer = inputdlg(prompt,dlg_title,num_lines,def);
if length(answer)==2
    new_win_time = str2double(answer(1));
    new_hop_time = str2double(answer(2));
    if ~(isnan(new_win_time)||isnan(new_hop_time))
        handles.win_time = new_win_time;
        handles.hop_time = new_hop_time;
        % si existe el campo significa que se levantaron los datos 
        if (isfield(handles,'audio_filename'))
            set(handles.status_info_text,'String','Load data again');drawnow;
        end
    else
        set(handles.status_info_text,'String','Invalid input data');drawnow;
    end
else
    set(handles.status_info_text,'String','Invalid input data');drawnow;
end

guidata(hObject, handles);


% --------------------------------------------------------------------
function pref_menu_editable_candidate_Callback(hObject, eventdata, handles)
% hObject    handle to pref_menu_editable_candidate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

prompt = {'Candidate Number'};
dlg_title = 'Editable Candidate';
num_lines = 1;
loaded_data = 0;
if isfield(handles,'editable_candidate')
    def = {num2str(handles.editable_candidate)};
    loaded_data = 1;
else
    def = {'1'};
end
answer = inputdlg(prompt,dlg_title,num_lines,def);

if (loaded_data)
    if length(answer)==1
        new_cand = str2double(answer(1));
        if (isnan(new_cand) || mod(new_cand,1)~=0 || new_cand>10)
            set(handles.status_info_text,'String','Invalid input data');drawnow;
        else
            if (handles.editable_candidate ~= new_cand)
                handles.editable_candidate = new_cand;
                
                %%%%%%%%%%%%%%%%
                
                % lectura del archivo con las etiquetas
                % last_version = 0 si no existe ningún archivo
                [lab_filename last_version] = get_current_labels_filename(handles.files_out_dir,new_cand);
                
                load(handles.f0gram_file,'f0_hyps_indxs');
                
                nc = size(f0_hyps_indxs,1);
                % contorno de f0 sin prostrocesar
                f0_contour_no_proc = f0_hyps_indxs(new_cand,:)';
                % otros candidatos
                f0_secondary_candidates = f0_hyps_indxs([1:new_cand-1 new_cand+1:nc],:)';
                %%% load labels
                if (last_version~=0)
                    f0_labels_file = [handles.files_out_dir filesep lab_filename];
                    T = dlmread(f0_labels_file, '\t');
                    % f0 labels
                    f0_contour = T(:,2);
                    f0_contour = interp1(handles.f0s,1:length(handles.f0s),f0_contour); % Los valores f0=0 quedan NaN
                    % salience lables
                    salience = T(:,3);
                    % manual correction label
                    manual = T(:,4);
                else
                    f0_contour = f0_contour_no_proc;
                    f0_contour(f0_contour==0)=1;
                    salience = handles.f0gram(sub2ind(size(handles.f0gram), f0_contour', 1:length(f0_contour)))';
                    manual = zeros(length(f0_contour),1);
                end
                % factor de normalizacion de la energia para plots
                fnorm_salience = length(handles.f0s)/max(salience);
                % frames agregados para completar una ventana
                % store data
                handles.f0_contour = [f0_contour; NaN*ones(handles.frames_add,1)];
                handles.salience = [salience*fnorm_salience; zeros(handles.frames_add,1)];
                handles.manual = [manual; zeros(handles.frames_add,1)];
                handles.f0_contour_no_proc = [f0_contour_no_proc; zeros(handles.frames_add,1)];
                handles.f0_secondary_candidates = [f0_secondary_candidates; zeros(handles.frames_add,nc-1)];
                handles.fnorm_salience = fnorm_salience;
                handles.last_version = last_version;
                %%%%%%%%%%%%%%%%
                add_new_plot_in_axes(handles);
            end
        end
    else
        set(handles.status_info_text,'String','Invalid input data');drawnow;
    end
else
    set(handles.status_info_text,'String','Data must be loaded first');drawnow;
end

guidata(hObject, handles);


% --- Executes on button press in source_button.
function source_button_Callback(hObject, eventdata, handles)
% hObject    handle to source_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in candidate_button.
function candidate_button_Callback(hObject, eventdata, handles)
% hObject    handle to candidate_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if isfield(handles,'editable_candidate')
    prompt = {'Candidate Number'};
    dlg_title = 'Change Candidate of the label';
    def = {num2str(handles.editable_candidate)};
    answer = inputdlg(prompt,dlg_title,1,def,'on');
    
    if length(answer)==1
        new_cand = str2double(answer(1));
        if (isnan(new_cand) || mod(new_cand,1)~=0 || new_cand>10)
            set(handles.status_info_text,'String','Invalid input data');drawnow;
        else
            if (handles.editable_candidate ~= new_cand)
                %handles.editable_candidate = new_cand;
                
                %%%%%%%%%%%
                
                % Rango de tiempo en el eje del f0grama
                h_axe = handles.f0gram_axes;
                time_lim = get(h_axe,'xlim');
                frames = find(handles.t>time_lim(1) & handles.t<time_lim(2));
                %f0_lim = get(h_axe,'ylim');
                %frames = frames((handles.f0_contour(frames)>=f0_lim(1))&(handles.f0_contour(frames)<=f0_lim(2)));
                % se guardan los datos viejos para el undo
                handles = undo_push(handles,frames);
                %%% Se cambian los valores del vector de f0
                if new_cand < handles.editable_candidate
                    idx_cand = new_cand;
                else
                    idx_cand = new_cand-1;
                end
                handles.f0_contour(frames) = handles.f0_secondary_candidates(frames,idx_cand);
                handles.manual(frames) = 1;
                f0gram = handles.f0gram(:,frames);
                
                handles.salience(frames) = handles.fnorm_salience/handles.fnrom_salience_unity*f0gram(sub2ind(size(f0gram), handles.f0_contour(frames)', 1:length(frames)))';
                
                % Se cambian los valores en la figura
                start_frame = handles.frame_idx(handles.actual_win);
                line = findobj(handles.f0gram_axes,'type','line','color','k');
                set(line,'xdata',handles.t(start_frame:start_frame+handles.win_frames-1),'ydata',handles.f0_contour(start_frame:start_frame+handles.win_frames-1))
                guidata(hObject, handles);
                
                %%%%%%%%%%%
                
            end
        end
    end
    
    
end



% --- Executes on button press in residual_button.
function residual_button_Callback(hObject, eventdata, handles)
% hObject    handle to residual_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
