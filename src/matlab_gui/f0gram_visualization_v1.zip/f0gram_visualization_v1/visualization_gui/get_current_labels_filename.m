function [lab_filename last_version] = get_current_labels_filename(directory,cand)

% Se elimina la barra final en el nombre del directorio
nd = length(directory);
if (directory(nd)==filesep)
    nd = nd-1;
    directory = directory(1:nd);
end

% Se parsea el nombre del directorio para obtener el último en el arbol
ind_bar = strfind(directory,filesep);
if (isempty(ind_bar))
    fname = directory;
else
    fname = directory(ind_bar(end)+1:nd);   
end

% Se obtienen los archivos del directorio
files_in_dir = dir(directory);
nfiles = length(files_in_dir);
% Se busca el archivo con numero de version mayor
if cand == 1
    regexp_fname = [fname '_f0_v(\d+).dat'];
else
    regexp_fname = [fname '_cand' num2str(cand) '_f0_v(\d+).dat'];
end
last_version_idx = 0;
last_version = 0;
for i = 1 : nfiles
    t = regexp(files_in_dir(i).name,regexp_fname,'tokens');
    if (~isempty(t))
        i_version = str2double(t{1}{1});
        if (i_version > last_version)
            last_version = i_version;
            last_version_idx = i;
        end
    end
end

if (last_version==0)
    lab_filename = '';
else
    lab_filename = files_in_dir(last_version_idx).name;
end
